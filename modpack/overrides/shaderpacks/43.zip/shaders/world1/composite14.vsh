#version 430 compatibility
#define WORLD_END
#define vsh
#include "/program/c19_color_grading.vsh"
