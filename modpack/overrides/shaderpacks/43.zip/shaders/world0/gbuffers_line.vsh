#version 430
#define WORLD_OVERWORLD
#define PROGRAM_GBUFFERS_LINE
#define vsh
#include "/program/gbuffers_basic.vsh"
