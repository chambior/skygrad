#version 430 compatibility
#define WORLD_OVERWORLD
#define PROGRAM_SHADOW
#define PROGRAM_SHADOW_SOLID
#define PROGRAM_SHADOW_BLOCK
#define COLORWHEEL
#define fsh
#include "/program/shadow.fsh"
