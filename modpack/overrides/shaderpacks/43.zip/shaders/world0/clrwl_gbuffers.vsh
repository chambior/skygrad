#version 430 compatibility
#define WORLD_OVERWORLD
#define PROGRAM_GBUFFERS_TERRAIN
#define PROGRAM_GBUFFERS_BLOCK
#define PROGRAM_GBUFFERS_ENTITIES
#define COLORWHEEL
#define vsh
#include "/program/gbuffers_all_solid.vsh"
