#version 430 compatibility
#define WORLD_OVERWORLD
#define fsh
#include "/program/c21_fxaa.fsh"
