#version 430 compatibility
#define WORLD_OVERWORLD
#define BLOOM_TILE_INDEX 1
#define vsh
#include "/program/c14_c18_bloom_upsample.vsh"


