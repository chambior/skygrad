layout(std430, binding = 1) readonly buffer SkygraduData {
    float wither_fog_density;
    float wither_fog_height_percent;
    float pad0;
    float pad1;
    vec3 wither_fog_color;
    float pad2;
};