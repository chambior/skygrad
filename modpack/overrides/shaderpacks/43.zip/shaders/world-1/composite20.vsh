#version 430 compatibility
#define WORLD_NETHER
#define vsh
#include "/program/c20_motion_blur.vsh"
