#version 430 compatibility
#define WORLD_NETHER
#define PROGRAM_COMPOSITE1
#define vsh
#include "/program/c1_blend_layers.vsh"
