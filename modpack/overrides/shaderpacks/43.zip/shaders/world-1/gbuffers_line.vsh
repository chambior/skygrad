#version 430
#define WORLD_NETHER
#define PROGRAM_GBUFFERS_LINE
#define vsh
#include "/program/gbuffers_basic.vsh"
