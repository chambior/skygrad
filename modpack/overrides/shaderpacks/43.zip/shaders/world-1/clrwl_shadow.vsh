#version 430 compatibility
#extension GL_ARB_shader_image_load_store : enable
#define WORLD_NETHER
#define PROGRAM_SHADOW
#define PROGRAM_SHADOW_SOLID
#define PROGRAM_SHADOW_BLOCK
#define COLORWHEEL
#define vsh
#include "/program/shadow.vsh"
