#version 430 compatibility
#define WORLD_NETHER
#define fsh
#include "/program/c21_fxaa.fsh"
