#version 430 compatibility
#define WORLD_NETHER
#define PROGRAM_DEFERRED2
#define fsh
#include "/program/d2_clouds_upscaling.fsh"
