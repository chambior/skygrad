#version 430 compatibility
#define WORLD_NETHER
#define PROGRAM_GBUFFERS_DAMAGEDBLOCK
#define COLORWHEEL
#define fsh
#include "/program/gbuffers_damagedblock.fsh"
