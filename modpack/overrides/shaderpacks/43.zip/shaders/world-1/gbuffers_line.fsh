#version 430
#define WORLD_NETHER
#define PROGRAM_GBUFFERS_LINE
#define fsh
#include "/program/gbuffers_basic.fsh"
