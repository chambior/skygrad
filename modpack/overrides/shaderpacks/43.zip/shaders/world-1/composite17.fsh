#version 430 compatibility
#define WORLD_NETHER
#define BLOOM_TILE_INDEX 1
#define fsh
#include "/program/c14_c18_bloom_upsample.fsh"

