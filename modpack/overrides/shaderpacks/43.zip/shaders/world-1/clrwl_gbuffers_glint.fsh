#version 430 compatibility
#define WORLD_NETHER
#define PROGRAM_GBUFFERS_ARMOR_GLINT
#define COLORWHEEL
#define fsh
#include "/program/gbuffers_armor_glint.fsh"
