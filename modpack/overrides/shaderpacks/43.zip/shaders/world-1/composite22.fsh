#version 430 compatibility
#define WORLD_NETHER
#define fsh
#include "/program/c22_copy_ao.fsh"
