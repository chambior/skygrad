#version 430 compatibility
#define WORLD_NETHER
#define fsh
#include "/program/c19_color_grading.fsh"
