#version 430 compatibility
#define WORLD_NETHER
#define vsh
#include "/program/c21_fxaa.vsh"
